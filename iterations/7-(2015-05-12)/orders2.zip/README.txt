# PHP Starter Application

Bluemix provides a PHP starter application as a template so that you can add your code and push the changes back to the Bluemix environment.


## Files

The PHP starter application has files as below:

*   index.php

	This file contains the server side PHP code for your application.

*   images/

	This directory contains images used by this application.

*   style.css

	This file contains the CSS used to display the HTML from index.php.


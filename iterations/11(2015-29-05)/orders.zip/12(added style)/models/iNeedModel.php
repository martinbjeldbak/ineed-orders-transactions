<?php

interface iNeedModel extends JsonSerializable {
}